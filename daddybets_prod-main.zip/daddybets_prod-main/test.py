import streamlit as st

print(st.session_state.to_dict())