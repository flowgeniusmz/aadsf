import streamlit as st
from forms import form_1_terms as ft, form_2_usertype as fu, form_3_existinguser as fe, form_3_newuser as fn